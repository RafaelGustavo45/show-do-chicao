public enum DifficultyLevel {
    FACIL,
    MEDIO,
    DIFICIL
}
